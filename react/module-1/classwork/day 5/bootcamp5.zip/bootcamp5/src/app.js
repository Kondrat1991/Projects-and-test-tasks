import React from 'react';
import Post from './components/post';
import PostList from './components/postsList'
import Timer from './components/timer';

const App = () => (
    <Timer/>
)
export default App;